<?php
$this->SET = array(
'last_action' => '0',
'last_db_backup' => 'top',
'tables' => '',
'comp_method' => '1',
'comp_level' => '7',
'last_db_restore' => 'top',
'tables_exclude' => '0',
)
?>