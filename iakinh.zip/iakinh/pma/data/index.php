<?php

header("location: ../index.php");

exit;

